<?php

/* 
   PHP Creating watermark image
 * Author : Sumith Harshan
 * Date   : 2012-10-05
 * Email  : sumith.harshan@gmail.com
*/


$fontPath 		= "MTCORSVA.TTF";
$fontSize 		= 20;  // in pixels
$watermarkText 	= "Watermark text here";


function watermarkProcess($oldImageName, $newImageName){
    global $fontPath, $fontSize, $watermarkText;
    list($oldImageWidth,$oldImageHeight) = getimagesize($oldImageName);
    $width  = 300;
	$height = 300;
	
	// CREATING TEMPORARY IMAGE    
    $imageTmp = imagecreatetruecolor($width, $height) or die('Cannot Initialize new GD image stream');
	
	// GET TEMPORARY IMAGE INFO(WIDTH & HEIGHT)
	$info = getimagesize($oldImageName);
	
	// Get image path from jpg/jpeg types
	if($info[2] == IMAGETYPE_JPEG){
	 	$imageTmpPath = imagecreatefromjpeg($oldImageName) or die('JPEG/JPEG Image type is open failed');
	}
	
	// Get image path from gif type
	if($info[2] == IMAGETYPE_PNG){
		$imageTmpPath = imagecreatefrompng($oldImageName) or die('PNG Image type is open failed');
	}
	
	// Get image path from png type
	if($info[2] == IMAGETYPE_GIF){
		$imageTmpPath = imagecreatefromgif($oldImageName) or die('GIF Image type is open failed');
	}
	
  	// Copy and resize part of an image with resampling
    imagecopyresampled($imageTmp, $imageTmpPath, 0, 0, 0, 0, $width, $height, $oldImageWidth, $oldImageHeight);

	// Decides text color by RGB value
    $color = imagecolorallocate($imageTmp, 59, 186, 10);
	
	// Create temp image text by inserting text to positions
    imagettftext($imageTmp, $fontSize, 0, 70, 270, $color, $fontPath, $watermarkText);
	
	/*
		0 - text rotation

		140 - x 
			The x-cordinate.From left-to-right distance.(simply like left padding of the image)
			
		270	- y

    		The y-cordinate. From top-to-bottom distance.(simply like top padding of the image)

	*/
	
	
	// Create image for jpg/jpeg types
	if($info[2] == IMAGETYPE_JPEG){
	 	imagejpeg($imageTmp, $newImageName, 100);
	}
	
	// Create image for gif type
	if($info[2] == IMAGETYPE_PNG){
		imagepng($imageTmp, $newImageName, 0);
	}
	
	// Create image for png type
	if($info[2] == IMAGETYPE_GIF){
		imagegif($imageTmp, $newImageName, 100);
	}
	
    // delete temporary image
    imagedestroy($imageTmp);
	
	// delete uploaded original image
    unlink($oldImageName);
    return true;
}


$textWithWatermark = "";
$imageWithWatermarkName 	= "";

if(isset($_POST['uploadedImage']) and $_POST['uploadedImage'] == "Submit"){
    $path 	 = "uploads/";
	// get valid image formats
    $valid_formats 	   = array('jpg','jpeg','png','gif');
	$uploadedImageName = $_FILES['imagefile']['name'];
	if(strlen($uploadedImageName))
	{
	   list($txt, $extension) = explode(".", $uploadedImageName);
	   
	   $fileSize = round( ($_FILES['imagefile']['size']/1024)/1024, 2 ); // size by mb
	   
	   if(in_array($extension,$valid_formats) && $_FILES['imagefile']['size'] <= 5242880) // limit to 5mb size
		{
			$upload_status = move_uploaded_file($_FILES['imagefile']['tmp_name'], $path.$_FILES['imagefile']['name']);
			if($upload_status)
			{
				$imgName 	  = time().'.'.$extension;
				$newNamePath  = $path.$imgName;
				// Call to the function
				if(watermarkProcess($path.$_FILES['imagefile']['name'], $newNamePath))
					$textWithWatermark 	= $newNamePath;
					$textWithWatermarkName = $imgName;
			}
		}
		else {
			$msg = "File size Max 5mb or Invalid file format supports jpg, jpeg, png, gif.<br/>You uploaded file size is ".$fileSize.'MB';
		}

	}
}



?>
<html>
    <head>
        <title>PHP Creating watermark text</title>
        
	<link rel="stylesheet" type="text/css" media="all" href="style.css" />
    </head>
    <body>
	
    <div class="form_wrapper">
    
        <h1>PHP Creating watermark text</h1>
            <form name="imageUpload" id="imageUpload" method="post" enctype="multipart/form-data" >
                <fieldset>
                    <legend>Upload Image</legend>
                    Image :<input type="file" name="imagefile" id="imagefile"/><br />
                    <input type="submit" name="uploadedImage" id="uploadedImage" value="Submit" />
                </fieldset>   
                <?php
                    if(!empty($textWithWatermark)) {
                        echo '<br/><center><img src="'.$textWithWatermark.'" /></center><br/>';
                        echo 'Image Name- '.$textWithWatermarkName;
                    }
                    else
                        echo '<h3>'.$msg.'</h3>';
                ?>
            </form>
            
      </div>
    
   
    </body>
</html>
