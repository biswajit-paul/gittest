<img src="mark.php?text=text" height="100" width="100">

<img src="demo1.php" height="100" width="100">

<img src="demo2.php">
