<?php

require_once(__DIR__.'/../src/PHPImageWorkshop/Exception/ImageWorkshopBaseException.php');
require_once(__DIR__.'/../src/PHPImageWorkshop/Exception/ImageWorkshopException.php');
require_once(__DIR__.'/../src/PHPImageWorkshop/Exif/ExifOrientations.php');
require_once(__DIR__.'/../src/PHPImageWorkshop/Core/Exception/ImageWorkshopLayerException.php');
require_once(__DIR__.'/../src/PHPImageWorkshop/Core/ImageWorkshopLib.php');
require_once(__DIR__.'/../src/PHPImageWorkshop/Core/ImageWorkshopLayer.php');
require_once(__DIR__.'/../src/PHPImageWorkshop/ImageWorkshop.php');
