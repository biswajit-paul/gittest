<form action="watermark-image.php" method="post" enctype="multipart/form-data">
    Select a file to upload for processing<br>
    <input type="file" name="File1"><br>
    <input type="submit" value="Submit File">
</form>