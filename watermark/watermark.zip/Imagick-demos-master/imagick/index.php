<?php

require "../src/process.php";
