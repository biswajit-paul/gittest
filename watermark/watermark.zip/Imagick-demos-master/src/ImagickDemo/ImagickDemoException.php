<?php

namespace ImagickDemo;

class ImagickDemoException extends \Exception
{

}
